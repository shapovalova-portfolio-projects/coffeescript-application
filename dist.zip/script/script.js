(function() {
  var History, MapPage, OverviewPage, Page, Structure, Tooltip, mapPage, navigation, overviewPage, steps,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  Page = (function() {
    function Page(id) {
      this.page = window.structure.pages[id];
      this.elements = {};
    }

    Page.prototype.getElementsOnce = function(elementsArray) {
      return elementsArray.forEach((function(_this) {
        return function(element) {
          return _this.elements[element] = _this.page.getElementsByClassName(element);
        };
      })(this));
    };

    Page.prototype.addAllElementsWithClassEventListener = function(elements, methods) {
      return elements.forEach((function(_this) {
        return function(elementClass, index) {
          var domElements;
          domElements = _this.page.getElementsByClassName(elementClass);
          return domElements.forEach(function(domElement) {
            return domElement.addEventListener('click', function() {
              return methods[index](domElement);
            });
          });
        };
      })(this));
    };

    Page.prototype.addElementsEventListener = function(elements, methods) {
      return elements.forEach((function(_this) {
        return function(element, index) {
          return element.addEventListener('click', function() {
            return methods[index](element);
          });
        };
      })(this));
    };

    Page.prototype.addExitEventListener = function(reset) {
      return [window.structure.menuBack, window.structure.menuNext].forEach((function(_this) {
        return function(menuButton) {
          return menuButton.addEventListener('click', function() {
            return reset();
          });
        };
      })(this));
    };

    return Page;

  })();

  Structure = (function() {
    function Structure() {
      var menu;
      this.pages = document.getElementById('pages').getElementsByClassName('page');
      menu = document.getElementById('menu');
      this.menuBack = menu.getElementsByClassName('back')[0];
      this.menuNext = menu.getElementsByClassName('next')[0];
      this.addMenuButtonsHandler(menu);
      this.setFirstPageActive();
    }

    Structure.prototype.addMenuButtonsHandler = function(menu) {
      this.menuBack.addEventListener('click', (function(_this) {
        return function() {
          return _this.goToPrevPage();
        };
      })(this));
      return this.menuNext.addEventListener('click', (function(_this) {
        return function() {
          return _this.goToNextPage();
        };
      })(this));
    };

    Structure.prototype.checkMenuButtons = function() {
      this.menuBack.classList.remove('hidden');
      this.menuNext.classList.remove('hidden');
      if (window.currentSlideIndex === 0) {
        return this.menuBack.classList.add('hidden');
      } else if (window.currentSlideIndex === this.pages.length - 1) {
        return this.menuNext.classList.add('hidden');
      }
    };

    Structure.prototype.goToPrevPage = function() {
      if (window.currentSlideIndex !== 0) {
        return this.goToPage(window.currentSlideIndex - 1);
      }
    };

    Structure.prototype.goToNextPage = function() {
      if (window.currentSlideIndex !== this.pages.length - 1) {
        return this.goToPage(window.currentSlideIndex + 1);
      }
    };

    Structure.prototype.goToPage = function(index) {
      this.pages[window.currentSlideIndex].classList.remove('active');
      this.pages[index].classList.add('active');
      window.currentSlideIndex = index;
      return this.checkMenuButtons();
    };

    Structure.prototype.setFirstPageActive = function() {
      window.currentSlideIndex = 0;
      return this.goToPage(0);
    };

    Structure.prototype.getPageIndexById = function(id) {
      var i, j, len, page, ref;
      i = 0;
      ref = this.pages;
      for (j = 0, len = ref.length; j < len; j++) {
        page = ref[j];
        if (page.id === id) {
          return i;
        }
        i++;
      }
      return -1;
    };

    return Structure;

  })();

  steps = {
    "step1": {
      "introduction": {
        "caption": "Introduction introduction introduction introduction",
        "text": ["Text text text text", "Another text text text"],
        "blocks": {
          "description": "One, or often, more than one description:",
          "list": ["list", "item", "list"]
        }
      },
      "content": {
        "header": "Can be managed",
        "text": ["Text text only text", "(Text here is necessary)"]
      },
      "next": [
        {
          "text": "Exclusively <br>text"
        }, {
          "text": "Next text text (text)"
        }
      ]
    },
    "step2": {
      "introduction": {
        "caption": "Text that describes the topic (Text an texts)"
      },
      "content": {
        "header": "Next text text",
        "list": ["List item #1", "Item #2", "Third list item", "Here is the last one"],
        "text": ["If text - most of text will text"]
      },
      "next": [
        {
          "text": "Another <br>placeholder"
        }, {
          "text": "Text – need more text"
        }
      ]
    },
    "step3": {
      "introduction": {
        "caption": "Improvement - need to text the text"
      },
      "content": {
        "header": "Text here and there",
        "text": ["(to be done)"]
      },
      "next": [
        {
          "text": "Text <br>return"
        }
      ],
      "resume": [
        {
          "caption": "No return of text"
        }
      ]
    },
    "step4": {
      "introduction": {
        "caption": "Content return"
      },
      "content": {
        "header": "Return to the top again."
      },
      "next": [
        {
          "text": "If text: <br>TEXTTTEXT"
        }, {
          "text": "Content <br>added"
        }
      ]
    },
    "step5": {
      "introduction": {
        "caption": "Text here: TEXTTTEXT"
      },
      "content": {
        "header": "Text added 9-12 times",
        "text": ["<b>Text filling</b> is then needed to determine if text achieved", "Performing a text adding is dependent on the answer to the question: Does the text have <b>any text?</b>"]
      },
      "next": [
        {
          "text": "No Current <br>text"
        }, {
          "text": "Current <br>text"
        }, {
          "text": "History of <br>text <br>adding <br>any time"
        }
      ]
    },
    "step6": {
      "introduction": {
        "caption": "Performing a text adding is dependent",
        "text": ["Mostly within minutes of text", "Mostly text"],
        "blocks": {
          "description": "One or more of these texts:",
          "list": ["LItem", "List", "Item too"]
        }
      },
      "content": {
        "sub_header": "Sub header",
        "header": "Extensively text",
        "text": ["(Initial choice, but some text may then need an <b>text</b> trial if not settling)", "Advise text to exclude all text from content", "Text testing needed.", "<b>If text confirmed (which may require a Text Challenge)</b> - Follow-up with text testing and later planned and Supervised Challenge to test for text", "Text referral required", "<b>If text to arrange is not in place - text</b>"]
      }
    },
    "step7": {
      "introduction": {
        "caption": "Follow-up with text testing caption",
        "text": ["Mostly text", "Initial choice, but some text"],
        "blocks": {
          "description": "Description:",
          "list": ["Some", "Another"]
        }
      },
      "content": {
        "sub_header": "Sub heaer text",
        "header": "Header",
        "text": ["Advise text to exclude all text", "Text:", "Follow-up with text testing", "Urgent dietetic referral"]
      }
    },
    "step8": {
      "introduction": {
        "caption": "Text do not settle"
      },
      "content": {
        "lists": [
          {
            "header": "Text still suspected:",
            "list": ["Refer to a text with an interest in text", "Consider a trial of <b>text</b>"]
          }, {
            "header": "Text no longer suspected:",
            "list": ["Unrestricted text again", "Consider referral to general text"]
          }
        ]
      }
    },
    "step9": {
      "introduction": {
        "caption": "Exclusively <br>Text"
      },
      "content": {
        "lists": [
          {
            "header": "Strict text",
            "list": ["Maternal supplements of text", "Refer to text", "If text - most content will text"]
          }
        ]
      },
      "next": [
        {
          "text": "No <br>improvement"
        }, {
          "text": "Improvement - need to confirm Text"
        }
      ]
    },
    "step10": {
      "introduction": {
        "caption": "Improvement - need to confirm Text"
      },
      "content": {
        "header": "Home Challenge: text over period of one week",
        "text": ["(to be done between 2-4 lines)"]
      },
      "next": [
        {
          "text": "Text <br>return"
        }
      ],
      "resume": [
        {
          "caption": "No return <br>of text: <br>TEXT"
        }
      ]
    },
    "step11": {
      "introduction": {
        "caption": "Text return"
      },
      "content": {
        "header": "Exclude text containing text from material again."
      },
      "next": [
        {
          "text": "If text settle: <br>TEXT <br><small>If top-up text needed: Use an <b>text</b></small>"
        }, {
          "text": "Text <br>do not settle"
        }
      ]
    },
    "step12": {
      "introduction": {
        "caption": "Text do not settle"
      },
      "content": {
        "lists": [
          {
            "header": "Text still suspected:",
            "list": ["Need to consider other material text", "Refer to a text with an interest in text"]
          }, {
            "header": "Text no longer suspected:",
            "list": ["Return to usual material text", "Consider referral to general text"]
          }
        ]
      }
    },
    "step13": {
      "introduction": {
        "caption": "Text settle: TEXTTTEXTTEXT"
      },
      "content": {
        "header": "And no history at any stage of text",
        "text": ["(No need to check text or perform content Test)", "<b>Text at Home - using a content LADDER</b>", "To test for text"]
      },
      "back": {
        "text": "No Current Text"
      }
    },
    "step14": {
      "introduction": {
        "caption": "Text settle: TEXTTTEXTTEXT"
      },
      "content": {
        "header": "Check text Specific"
      },
      "back": {
        "text": "Current text"
      },
      "resume": [
        {
          "caption": "Negative",
          "text": ["And still no history at any stage of text", "<b>Text at Home -</b> using a content LADDER to test for text"]
        }, {
          "caption": "Positive",
          "text": ["<b>Refer to a text with an interest in text</b>", "(A <b>text Challenge</b> may be needed)"]
        }
      ]
    },
    "step15": {
      "introduction": {
        "caption": "Text settle: TEXTTEXTTEXT"
      },
      "content": {
        "header": "Text Specific Test needed"
      },
      "back": {
        "text": "History of text at any time"
      },
      "resume": [
        {
          "caption": "Negative",
          "text": ["Text"]
        }, {
          "caption": "Positive",
          "text": ["(or texxt)", "<b>Refer to content</b>", "(A <b>text</b> may be needed)"]
        }
      ]
    }
  };

  navigation = {
    "map": {
      "step1": {
        "next": ["step9", "step2"]
      },
      "step2": {
        "next": ["step8", "step3"]
      },
      "step3": {
        "next": ["step4"]
      },
      "step4": {
        "next": ["step5", "step8"]
      },
      "step5": {
        "next": ["step13", "step14", "step15"]
      },
      "step6": {},
      "step7": {},
      "step8": {},
      "step9": {
        "next": ["step12", "step10"]
      },
      "step10": {
        "next": ["step11"]
      },
      "step11": {
        "next": ["step5", "step12"]
      },
      "step12": {},
      "step13": {
        "back": "step5"
      },
      "step14": {
        "back": "step5"
      },
      "step15": {
        "back": "step5"
      }
    }
  };

  HTMLCollection.prototype.forEach = Array.prototype.forEach;

  History = (function() {
    function History() {
      this.clear();
    }

    History.prototype.getAllStepsData = function(slideId) {
      this.allStepsNavigation = navigation;
      return this.allStepsData = steps;
    };

    History.prototype.getStepData = function(stepId) {
      var step;
      step = {};
      step.id = stepId;
      step.data = this.allStepsData[stepId];
      step.next = this.allStepsNavigation.map[stepId].next;
      step.back = this.allStepsNavigation.map[stepId].back;
      return step;
    };

    History.prototype.clear = function() {
      this.steps = [];
      return this.currentStep = {};
    };

    History.prototype.stepNext = function(stepId) {
      var step;
      step = this.getStepData(stepId);
      if (step) {
        this.steps.push(step);
        this.currentStep = step;
        this.removeIllegalSteps();
        this.setBackButton();
      }
      return this.currentStep;
    };

    History.prototype.stepBack = function(stepId) {
      if (this.isStepInStack(stepId)) {
        while (this.steps.length > 0) {
          if (this.steps.pop().id === stepId) {
            break;
          }
        }
        return this.currentStep = this.getLastElement();
      } else {
        return this.stepNext(stepId);
      }
    };

    History.prototype.isStepInStack = function(stepId) {
      return this.steps.some(function(step) {
        return step.id === stepId;
      });
    };

    History.prototype.setBackButton = function() {
      if (this.currentStep.back) {
        return this.removeStep(this.currentStep.back);
      }
    };

    History.prototype.removeStep = function(stepId) {
      return this.steps = this.steps.filter(function(step) {
        return stepId !== step.id;
      });
    };

    History.prototype.getLastElement = function() {
      if (this.steps.length > 0) {
        return this.steps[this.steps.length - 1];
      } else {
        return {};
      }
    };

    History.prototype.isCurrentStep = function(step) {
      return step.id === this.currentStep.id;
    };

    History.prototype.getStepNumber = function(step) {
      return Number(step.replace('step', ''));
    };

    History.prototype.removeIllegalSteps = function() {
      this.legalSteps = this.steps.filter((function(_this) {
        return function(step) {
          return _this.getStepNumber(step.id) <= _this.getStepNumber(_this.currentStep.id);
        };
      })(this));
      return this.steps = this.legalSteps;
    };

    return History;

  })();

  window.History = new History();

  Tooltip = (function() {
    function Tooltip(tooltip, page) {
      this.tooltip = tooltip;
      this.page = page;
      this.openAttribute = 'data-tooltip';
      this.addCloseHandler();
      this.initialise();
    }

    Tooltip.prototype.addCloseHandler = function() {
      var closeArea;
      closeArea = document.body;
      return closeArea.addEventListener('tap', (function(_this) {
        return function() {
          if (!(_this.tooltip.contains(event.target) || _this.isActiveTooltipButton(event.target))) {
            return _this.hide();
          }
        };
      })(this), true);
    };

    Tooltip.prototype.initialise = function() {
      var openButton;
      if (this.page.getElementsByClassName(this.openAttribute).length) {
        openButton = this.page.getElementsByClassName(this.props.open)[0];
        openButton.addEventListener('tap', (function(_this) {
          return function() {
            return _this.show();
          };
        })(this));
        return true;
      } else {
        return false;
      }
    };

    Tooltip.prototype.isActiveTooltipButton = function(element) {
      return element.classList.contains(this.openAttribute) && element.classList.contains("active");
    };

    Tooltip.prototype.show = function() {
      this.openButton = event.target;
      if (this.isActiveTooltipButton(this.openButton)) {
        this.hide();
        return event.stopPropagation();
      } else {
        this.openButton.classList.add("active");
        return this.tooltip.classList.add('show');
      }
    };

    Tooltip.prototype.hide = function() {
      if (this.openButton) {
        this.openButton.classList.remove("active");
      }
      this.openButton = null;
      return this.tooltip.classList.remove('show');
    };

    return Tooltip;

  })();

  window.Tooltip = Tooltip;

  window.structure = new Structure();

  MapPage = (function(superClass) {
    extend(MapPage, superClass);

    function MapPage(id) {
      this.goToPreviousStep = bind(this.goToPreviousStep, this);
      this.goToNextStep = bind(this.goToNextStep, this);
      this.resetToInitial = bind(this.resetToInitial, this);
      MapPage.__super__.constructor.call(this, id);
      this.firstStep = 'step0';
      this.stepsStackDomElement = this.page.getElementsByClassName('steps-stack')[0];
      this.addAllElementsWithClassEventListener(['next', 'back'], [this.goToNextStep, this.goToPreviousStep]);
      this.addExitEventListener(this.resetToInitial);
      this.history = window.History;
      this.history.getAllStepsData(id);
      this.changeStepTo(this.firstStep);
    }

    MapPage.prototype.checkMode = function() {
      if (!this.page.classList.contains("steps-mode")) {
        return this.page.classList.add("steps-mode");
      }
    };

    MapPage.prototype.resetToInitial = function() {
      this.history.clear();
      this.goToFirstStep();
      return this.page.classList.remove("steps-mode");
    };

    MapPage.prototype.clearStepsStackElement = function() {
      this.stepsStackDomElement.classList.remove("single-step");
      return this.stepsStackDomElement.innerHTML = '';
    };

    MapPage.prototype.createHeader2 = function(text) {
      var header2;
      header2 = document.createElement('h2');
      header2.innerHTML = text;
      return header2;
    };

    MapPage.prototype.createButton = function(dataAttributeValue) {
      var backButton;
      backButton = document.createElement('button');
      backButton.setAttribute('data-goto-step', dataAttributeValue);
      backButton.classList.add('arrow');
      backButton.classList.add('back');
      backButton.addEventListener('click', (function(_this) {
        return function() {
          _this.goToPreviousStep();
          return event.preventDefault();
        };
      })(this));
      return backButton;
    };

    MapPage.prototype.createParagraph = function(text) {
      var paragraph;
      paragraph = document.createElement('p');
      paragraph.innerHTML = text;
      return paragraph;
    };

    MapPage.prototype.createList = function(list) {
      var blocksList;
      blocksList = document.createElement('ul');
      list.forEach((function(_this) {
        return function(item) {
          var listItem;
          listItem = document.createElement('li');
          listItem.innerHTML = item;
          return blocksList.appendChild(listItem);
        };
      })(this));
      return blocksList;
    };

    MapPage.prototype.createDiv = function(blocksContent) {
      var blocks;
      blocks = document.createElement('div');
      if (blocksContent.description) {
        blocks.appendChild(this.createParagraph(blocksContent.description));
      }
      if (blocksContent.blocks_list) {
        blocks.appendChild(this.createList(blocksContent.blocks_list));
      }
      return blocks;
    };

    MapPage.prototype.createStepElement = function(step, isCurrentStep) {
      var stepData, stepDiv;
      if (isCurrentStep == null) {
        isCurrentStep = false;
      }
      if (step.data) {
        stepData = step.data.introduction;
        stepDiv = document.createElement('div');
        stepDiv.appendChild(this.createButton(step.id));
        stepDiv.appendChild(this.createHeader2(stepData.caption));
        if (isCurrentStep) {
          if (stepData.text) {
            stepData.text.forEach((function(_this) {
              return function(paragraph) {
                return stepDiv.appendChild(_this.createParagraph(paragraph));
              };
            })(this));
          }
          if (stepData.blocks) {
            stepDiv.appendChild(this.createDiv(stepData.blocks));
          }
        }
        return stepDiv;
      } else {
        return null;
      }
    };

    MapPage.prototype.updateStepsStack = function() {
      this.clearStepsStackElement();
      this.history.steps.forEach((function(_this) {
        return function(step) {
          var stepElement;
          stepElement = _this.createStepElement(step, _this.history.isCurrentStep(step));
          return _this.stepsStackDomElement.appendChild(stepElement);
        };
      })(this));
      if (this.history.steps.length === 1) {
        return this.stepsStackDomElement.classList.add("single-step");
      }
    };

    MapPage.prototype.goToFirstStep = function() {
      return this.changeStepTo(this.firstStep);
    };

    MapPage.prototype.goToStep = function(step) {
      if (step) {
        this.changeStepTo(step);
        this.updateStepsStack();
        return this.checkMode();
      }
    };

    MapPage.prototype.goToNextStep = function() {
      var buttonIndex, ref, ref1, step;
      step = (ref = event.target.attributes['data-goto-step']) != null ? ref.value : void 0;
      if (!step) {
        buttonIndex = (ref1 = event.target.attributes['data-button-index']) != null ? ref1.value : void 0;
        step = this.history.currentStep.next[buttonIndex];
      }
      this.history.stepNext(step);
      return this.goToStep(step);
    };

    MapPage.prototype.goToPreviousStep = function() {
      var ref, step;
      step = (ref = event.target.attributes['data-goto-step']) != null ? ref.value : void 0;
      if (!step || step === this.history.steps[0].id) {
        return this.resetToInitial();
      } else {
        step = this.history.stepBack(step).id;
        return this.goToStep(step);
      }
    };

    MapPage.prototype.changeStepTo = function(step) {
      this.page.classList.remove(this.page.currentStep);
      this.page.classList.add(step);
      return this.page.currentStep = step;
    };

    return MapPage;

  })(Page);

  mapPage = new MapPage('map');

  OverviewPage = (function(superClass) {
    extend(OverviewPage, superClass);

    function OverviewPage(id) {
      this.setActive = bind(this.setActive, this);
      this.disableActive = bind(this.disableActive, this);
      var moduleElements;
      OverviewPage.__super__.constructor.call(this, id);
      moduleElements = this.page.getElementsByClassName("modules-container")[0].children;
      this.activeElement = null;
      this.addAllElementsWithClassEventListener(["info"], [this.setActive]);
      this.addElementsEventListener(moduleElements, [this.goToPage, this.goToPage]);
      this.addExitEventListener(this.disableActive);
    }

    OverviewPage.prototype.disableActive = function() {
      var ref;
      if ((ref = this.activeElement) != null) {
        ref.classList.remove("active");
      }
      return this.activeElement = null;
    };

    OverviewPage.prototype.setActive = function(tappedElement) {
      if (!tappedElement.classList.contains("active")) {
        this.disableActive();
        tappedElement.classList.add("active");
        return this.activeElement = tappedElement;
      }
    };

    OverviewPage.prototype.goToPage = function(element) {
      var index, pageId;
      pageId = element.attributes['data-page'].value;
      index = window.structure.getPageIndexById(pageId);
      return window.structure.goToPage(index);
    };

    return OverviewPage;

  })(Page);

  overviewPage = new OverviewPage('overview');

}).call(this);
